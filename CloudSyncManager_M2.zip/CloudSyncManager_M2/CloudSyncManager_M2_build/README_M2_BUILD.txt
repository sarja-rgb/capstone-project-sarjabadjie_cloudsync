CloudSync Manager - Milestone 2 Build
Student: Sarja Badjie

How to run:
1) Open a terminal in this folder
2) Create venv: python -m venv venv
3) Activate: venv\Scripts\activate
4) Install deps: pip install -r requirements.txt
5) Run app: python main.py

Notes:
- Milestone 2 focuses on literature review, competing products, and feature set updates.
- Latest repo: https://github.com/FullSailGameStudies/capstone-project-sarjabadjie_cloudsync
- Milestone 2 commit: 8d63786ed7970bcbf76103b26a96e3fff55d68ed
