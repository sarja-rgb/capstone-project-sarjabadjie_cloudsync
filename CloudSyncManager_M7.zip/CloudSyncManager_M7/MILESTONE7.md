# Milestone 7 Submission Notes

**Build:** CloudSyncManager_M7

This build packages the latest functional progress for Milestone 7:
- PyQt GUI for configuring a local folder + S3 bucket settings (saved to SQLite)
- "Test S3 Connection" operation that lists objects (safe read-only list)
- Milestone 7 demo UI with status/progress bar and log output written to `sync_log.txt`

## How to run
1. `pip install -r requirements.txt`
2. Run the main configuration + S3 test GUI:
   - `python main.py`
3. Run the Milestone 7 demo UI:
   - `python milestone7_ui.py`
